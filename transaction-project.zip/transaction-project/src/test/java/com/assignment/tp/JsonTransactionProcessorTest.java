package com.assignment.tp;

import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.junit.Assert.assertEquals;

public class JsonTransactionProcessorTest {

    private TransactionProcessor jsonTransactionProcessor;

    @Before
    public void setUp() {
        jsonTransactionProcessor = null;// replace the null with your JSON implementation class
    }

    @Test
    public void givenValidJsonStream_WhenImport_ThenReturnTheExpectedTransactions() {

        InputStream is = asStream("test-case1.json");
        jsonTransactionProcessor.importTransactions(is);
        List<Transaction> transactions = jsonTransactionProcessor.getImportedTransactions();

        assertThat(transactions, containsInAnyOrder(
                newTransaction("D", new BigDecimal(200), "rent"),
                newTransaction("C", new BigDecimal(1000), "salary"),
                newTransaction("D", new BigDecimal(800), "other")
        ));
    }

    @Test
    public void givenBalancedJsonStream_WhenImportAndCheckIfBalanced_ThenReturnTrue() throws Exception {
        InputStream is = asStream("test-case2.json");
        jsonTransactionProcessor.importTransactions(is);

        assertEquals(true, jsonTransactionProcessor.isBalanced());
    }

    @Test
    public void givenImbalancedJsonStream_WhenImportAndCheckIfBalanced_ThenReturnFalse() throws Exception {
        InputStream is = asStream("test-case3.json");
        jsonTransactionProcessor.importTransactions(is);

        assertEquals(false, jsonTransactionProcessor.isBalanced());
    }

    @Test
    public void givenJsonStreamWithAnInvalidTransaction_WhenCallingValidate_ThenReportTheProperViolations() throws Exception {
        InputStream is = asStream("test-case4.json");
        jsonTransactionProcessor.importTransactions(is);
        List<Violation> violations = jsonTransactionProcessor.validate();

        assertThat(violations, containsInAnyOrder(new Violation(2, "type")));
    }

    @Test
    public void givenJsonStreamWithMultipleInvalidTransactions_WhenCallingValidate_ThenReportTheProperViolations() throws Exception {
        InputStream is = asStream("test-case5.json");
        jsonTransactionProcessor.importTransactions(is);
        List<Violation> violations = jsonTransactionProcessor.validate();

        assertThat(violations, containsInAnyOrder(new Violation(2, "type"), new Violation(1, "amount")));
    }

    @Test
    public void givenJsonStreamWithMultipleErrorsInSameTransaction_WhenCallingValidate_ThenReportTheProperViolations() throws Exception {
        InputStream is = asStream("test-case6.json");
        jsonTransactionProcessor.importTransactions(is);
        List<Violation> violations = jsonTransactionProcessor.validate();

        assertThat(violations, containsInAnyOrder(new Violation(2, "type"), new Violation(2, "amount"), new Violation(1, "amount")));
    }

    private Transaction newTransaction(String type, BigDecimal amount, String narration) {
        return new Transaction(type, amount, narration);
    }

    private InputStream asStream(String s) {
        return getClass().getClassLoader().getResourceAsStream(s);
    }
}
